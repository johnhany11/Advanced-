package service;

import dao.UserDAO;
import model.Customer;
import model.Seller;
import model.User;

public class UserService {

    private final UserDAO userDAO = new UserDAO();
    private static int idCounter = 1;

    public void register(String username, String email, String password, String role) {
        User user;

        if (role.equalsIgnoreCase("CUSTOMER")) {
            user = new Customer(idCounter++, username, email, password);
        } else {
            user = new Seller(idCounter++, username, email, password);
        }

        userDAO.save(user);
    }

    public User login(String username, String password) {
        return userDAO.findByUsernameAndPassword(username, password);
    }
}
