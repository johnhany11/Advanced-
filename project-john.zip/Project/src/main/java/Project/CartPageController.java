package Project;

/*
package com.mycompany.project;

import java.net.URL;
import java.util.ResourceBundle;
import javafx.fxml.FXML;
import javafx.fxml.Initializable;
import javafx.scene.control.ListView;

public class CartPageController implements Initializable {

    @FXML
    private ListView<String> cartList;

    @Override
    public void initialize(URL url, ResourceBundle rb) {
        for (CartItem item : CartData.getItems()) {
            cartList.getItems().add(item.getName());
        }
    }
}
*/