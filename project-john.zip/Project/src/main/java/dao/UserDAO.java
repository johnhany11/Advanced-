package dao;

import model.User;
import java.util.ArrayList;
import java.util.List;

public class UserDAO {

    private static final List<User> users = new ArrayList<>();

    public void save(User user) {
        users.add(user);
    }

    public User findByUsernameAndPassword(String username, String password) {
        for (User u : users) {
            if (u.getUsername().equals(username) &&
                u.getPassword().equals(password)) {
                return u;
            }
        }
        return null;
    }
}
