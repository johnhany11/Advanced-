package model;

public class Bed extends FurnitureItem{
    private String size;

    public Bed(int itemid, String name, double price, String material, int stock, String size) {

        super(itemid, name, price, material, stock);
        this.size = size;
    }

    public String getSize() {
        return size;
    }

    @Override
    public String toString() {
        return super.toString() + ", Size: " + size;
    }
}

