package model;

public class Customer extends User {

    public Customer(int id, String username, String email, String password) {
        super(id, username, email, password);
    }

    @Override
    public String getRole() {
        return "CUSTOMER";
    }
}
