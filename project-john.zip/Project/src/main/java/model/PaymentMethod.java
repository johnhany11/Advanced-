package model;


public interface PaymentMethod {
    boolean pay(double amount);
}
