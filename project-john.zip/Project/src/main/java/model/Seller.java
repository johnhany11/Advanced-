package model;

public class Seller extends User {

    public Seller(int id, String username, String email, String password) {
        super(id, username, email, password);
    }

    @Override
    public String getRole() {
        return "SELLER";
    }
}
