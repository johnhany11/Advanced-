package model;

public class Sofa extends FurnitureItem {
    private int seats;
    private String color;

    
    public Sofa(int itemId, String name, double price, String material, int stock, int seats, String color) {
        
        
        super(itemId, name, price, material, stock);
        
        this.seats = seats;
        this.color = color;
    }

    public int getSeats() {
        return seats;
    }

    public String getColor() {
        return color;
    }

    @Override
    public String getDescription() {
        return "Color: " + color + ", Seats: " + seats;
    }
    
    @Override
    public String toString() {
        return super.toString() + " - " + color;
    }
}