package model;

public class Table extends FurnitureItem {

    private String shape;
    private String dimensions;

    
    public Table(int itemid, String name, double price, String material, 
                 int stock, String shape, String dimensions) {

     
        super(itemid, name, price, material, stock); 
        this.shape = shape;
        this.dimensions = dimensions;
    }

    public String getShape() { return shape; }
    public String getDimensions() { return dimensions; }

    @Override
    public String toString() {
        return super.toString() + ", Shape: " + shape;
    }

    @Override
    public String getDescription() {
        return "Shape: " + shape + ", Dimensions: " + dimensions;
    }
}