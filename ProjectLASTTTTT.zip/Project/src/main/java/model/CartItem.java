package model;

public class CartItem {
    private FurnitureItem furniture; // Using your existing class
    private int quantity;

    public CartItem(FurnitureItem furniture, int quantity) {
        this.furniture = furniture;
        this.quantity = quantity;
    }

    public FurnitureItem getFurniture() {
        return furniture;
    }

    public int getQuantity() {
        return quantity;
    }
    
    // This method decides what text appears in the ListView
    @Override
    public String toString() {
        // Assuming FurnitureItem has getName() and getPrice()
        return furniture.getName() + " (x" + quantity + ") - $" + (furniture.getPrice() * quantity);
    }
}