package model;
import service.*;
import exceptions.*; // Import your custom exceptions

import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;

public class Main {

    // --- SERVICES (The "Brain" of the application) ---
    private static final UserService userService = new UserService();
    private static final FurnitureService furnitureService = new FurnitureService();
    private static final OrderService orderService = new OrderService();
    // (WarehouseService is optional for the main customer flow, but you can add it if needed)

    private static final Scanner scanner = new Scanner(System.in);
    private static User currentUser = null;

    public static void main(String[] args) {
        // 1. SETUP: Pre-register a dummy user so you can test logging in immediately
        setupDummyData();

        System.out.println("=========================================");
        System.out.println("   Welcome to Furniture E-Commerce App   ");
        System.out.println("      (Backend Service Logic Test)       ");
        System.out.println("=========================================");

        boolean running = true;
        while (running) {
            if (currentUser == null) {
                showLoginMenu();
            } else {
                if (currentUser.getRole().equals("CUSTOMER")) {
                    showCustomerMenu();
                } else {
                    showSellerMenu();
                }
            }
        }
    }

    // =========================================================================
    // 1. LOGIN & REGISTRATION
    // =========================================================================

    private static void showLoginMenu() {
        System.out.println("\n--- START MENU ---");
        System.out.println("1. Login");
        System.out.println("2. Register New Account");
        System.out.println("3. Exit");
        System.out.print("Choose option: ");
        
        String choice = scanner.nextLine();
        
        switch (choice) {
            case "1":
                performLogin();
                break;
            case "2":
                performRegistration();
                break;
            case "3":
                System.out.println("Goodbye!");
                System.exit(0);
                break;
            default:
                System.out.println("Invalid option.");
        }
    }

    private static void performLogin() {
        System.out.print("Enter Username: ");
        String username = scanner.nextLine();
        System.out.print("Enter Password: ");
        String password = scanner.nextLine();

        // SERVICE CALL: The Service talks to the DAO to find the user
        User user = userService.login(username, password);

        if (user != null) {
            currentUser = user;
            System.out.println("Login Successful! Welcome, " + user.getUsername());
        } else {
            System.out.println("Login Failed. Invalid credentials.");
        }
    }

    private static void performRegistration() {
        System.out.println("\n--- REGISTER ---");
        System.out.print("Enter Username: ");
        String username = scanner.nextLine();
        System.out.print("Enter Email: ");
        String email = scanner.nextLine();
        System.out.print("Enter Password: ");
        String pass = scanner.nextLine();
        System.out.print("Role (CUSTOMER/SELLER): ");
        String role = scanner.nextLine();

        // SERVICE CALL: Register passes data to Service -> DAO
        userService.register(username, email, pass, role);
        System.out.println("Registration successful! Please login.");
    }

    // =========================================================================
    // 2. CUSTOMER MENU
    // =========================================================================

    private static void showCustomerMenu() {
        System.out.println("\n--- CUSTOMER DASHBOARD (" + currentUser.getUsername() + ") ---");
        System.out.println("1. View All Furniture (Sorted by Price)");
        System.out.println("2. Add Item to Cart");
        System.out.println("3. View Cart & Checkout");
        System.out.println("4. Logout");
        System.out.print("Choose option: ");

        String choice = scanner.nextLine();
        switch (choice) {
            case "1":
                viewCatalog();
                break;
            case "2":
                addToCart();
                break;
            case "3":
                checkout();
                break;
            case "4":
                currentUser.logout();
                currentUser = null;
                break;
            default:
                System.out.println("Invalid option.");
        }
    }

    private static void viewCatalog() {
        System.out.println("\n--- CATALOG (Sorted Low to High) ---");
        
        // 1. Aggregate all items into one list for display
        List<FurnitureItem> allItems = new ArrayList<>();
        allItems.addAll(furnitureService.getAllSofas());
        allItems.addAll(furnitureService.getAllBeds());
        allItems.addAll(furnitureService.getAllTables());

        // 2. GENERIC SORT DEMO: Use the method you wrote in FurnitureService
        furnitureService.sortFurnitureByPrice(allItems);

        // 3. Display
        for (FurnitureItem item : allItems) {
            System.out.println("[" + item.getItemId() + "] " + item.getName() + " - $" + item.getPrice());
            System.out.println("    Details: " + item.getDescription());
        }
    }

    private static void addToCart() {
        System.out.print("Enter Item ID to buy: ");
        try {
            int id = Integer.parseInt(scanner.nextLine());
            
            // NOTE: In a real app, we would search by ID in the DB. 
            // For this main loop, we'll just quickly find it in our lists.
            FurnitureItem selected = findItemById(id);

            if (selected != null) {
                // SERVICE CALL: Get the static active cart and add item
                Order cart = OrderService.getActiveCart();
                orderService.addItemToOrder(cart, selected);
            } else {
                System.out.println("Item not found.");
            }
        } catch (NumberFormatException e) {
            System.out.println("Invalid number format.");
        }
    }

    private static void checkout() {
        Order cart = OrderService.getActiveCart();
        
        if (cart.getItems().isEmpty()) {
            System.out.println("\nYour cart is empty!");
            return;
        }

        System.out.println("\n--- CHECKOUT ---");
        System.out.println("Items in Cart: " + cart.getItems().size());
        System.out.println("Total Total: $" + cart.calculateTotal());
        
        System.out.print("Confirm Purchase? (y/n): ");
        String confirm = scanner.nextLine();
        
        if (confirm.equalsIgnoreCase("y")) {
            // SERVICE CALL: Finalize order and save to OrderDAO
            orderService.checkout(cart);
        }
    }

    // =========================================================================
    // 3. SELLER MENU (Optional Demo)
    // =========================================================================

    private static void showSellerMenu() {
        System.out.println("\n--- SELLER DASHBOARD ---");
        System.out.println("1. View Sales History (All Orders)");
        System.out.println("2. Logout");
        System.out.print("Choose option: ");
        
        String choice = scanner.nextLine();
        if (choice.equals("1")) {
            List<Order> history = orderService.getAllOrders();
            System.out.println("\n--- SALES HISTORY ---");
            if (history.isEmpty()) System.out.println("No sales yet.");
            for (Order o : history) {
                System.out.println("Order #" + o.getOrderId() + " | Total: $" + o.calculateTotal() + " | Status: " + o.getStatus());
            }
        } else if (choice.equals("2")) {
            currentUser.logout();
            currentUser = null;
        }
    }

    // =========================================================================
    // UTILITIES & SETUP
    // =========================================================================

    private static void setupDummyData() {
        // Create a default customer so you don't have to register every time you run
        userService.register("alice", "alice@test.com", "1234", "CUSTOMER");
        userService.register("admin", "admin@store.com", "admin", "SELLER");
        System.out.println("(Debug: Test User 'alice' created with password '1234')");
    }

    // Helper to find an item across all lists (Simulates a 'findById' database query)
    private static FurnitureItem findItemById(int id) {
        List<FurnitureItem> all = new ArrayList<>();
        all.addAll(furnitureService.getAllSofas());
        all.addAll(furnitureService.getAllBeds());
        all.addAll(furnitureService.getAllTables());
        
        for (FurnitureItem item : all) {
            if (item.getItemId() == id) return item;
        }
        return null;
    }
}














/*
package model;

import java.util.Scanner;
import java.util.List;

public class Main {
    // Scanner for reading input
    private static Scanner scanner = new Scanner(System.in);
    private static ECommerceSystem system = new ECommerceSystem();
    private static User currentUser = null;
    private static Order currentOrder = null;
    private static int orderIdCounter = 1;

    public static void main(String[] args) {
        // 1. Setup Dummy Data (Database simulation)
        initializeSystemData();

        System.out.println("=========================================");
        System.out.println("   Welcome to Furniture E-Commerce App   ");
        System.out.println("=========================================");

        boolean running = true;
        while (running) {
            if (currentUser == null) {
                showLoginMenu();
            } else {
                showCustomerMenu();
            }
        }
    }

    // --- MENUS ---

    private static void showLoginMenu() {
        System.out.println("\n--- LOGIN ---");
        System.out.print("Enter Email (try 'alice@test.com'): ");
        String email = scanner.nextLine();
        // Simple password simulation
        System.out.print("Enter Password (any): ");
        String password = scanner.nextLine();

        // Find user in system
        for (User u : system.getUsers()) {
            if (u.getEmail().equalsIgnoreCase(email)) {
                if (u.login(email, password)) {
                    currentUser = u;
                    // Initialize a new order for this session
                    if (currentUser instanceof Customer) {
                        currentOrder = new Order(orderIdCounter++, (Customer) currentUser);
                    }
                    return;
                }
            }
        }
        System.out.println("User not found or login failed.");
    }

    private static void showCustomerMenu() {
        System.out.println("\n--- MAIN MENU (" + currentUser.getUsername() + ") ---");
        System.out.println("1. View All Items (Sorted by Price)");
        System.out.println("2. Search Items");
        System.out.println("3. Add Item to Order");
        System.out.println("4. View Cart & Checkout");
        System.out.println("5. Logout");
        System.out.print("Choose option: ");

        String choice = scanner.nextLine();
        switch (choice) {
            case "1":
                viewSortedItems();
                break;
            case "2":
                searchForItems();
                break;
            case "3":
                addToCart();
                break;
            case "4":
                checkout();
                break;
            case "5":
                currentUser.logout();
                currentUser = null;
                currentOrder = null;
                break;
            default:
                System.out.println("Invalid option.");
        }
    }

    // --- ACTIONS ---

    private static void viewSortedItems() {
        System.out.println("\n--- Available Furniture (Low to High Price) ---");
        // Sort items using the Comparable implementation you wrote
        system.sortItems();
        
        List<FurnitureItem> items = system.getAllItems();
        for (FurnitureItem item : items) {
            System.out.println("ID: " + item.getItemId() + " | " + item.toString() + " | Price: $" + item.getPrice());
        }
    }

    private static void searchForItems() {
        System.out.print("Enter keyword (e.g., 'Wood', 'King', 'Office'): ");
        String keyword = scanner.nextLine();
        
        // This relies on the fix we made in ECommerceSystem (using getMaterial instead of description)
        List<FurnitureItem> results = system.searchItems(keyword);
        
        if (results.isEmpty()) {
            System.out.println("No items found.");
        } else {
            for (FurnitureItem item : results) {
                System.out.println("Found: " + item.getName() + " - " + item.getMaterial() + " ($" + item.getPrice() + ")");
            }
        }
    }

    private static void addToCart() {
        System.out.print("Enter Item ID to buy: ");
        try {
            int id = Integer.parseInt(scanner.nextLine());
            // Find the item manually for this test
            FurnitureItem selected = null;
            for (FurnitureItem item : system.getAllItems()) {
                if (item.getItemId() == id) {
                    selected = item;
                    break;
                }
            }

            if (selected != null) {
                currentOrder.addItem(selected);
                System.out.println(selected.getName() + " added to your cart.");
            } else {
                System.out.println("Item ID not found.");
            }
        } catch (NumberFormatException e) {
            System.out.println("Invalid ID format.");
        }
    }

    private static void checkout() {
        System.out.println("\n--- CHECKOUT ---");
        if (currentOrder.getItems().isEmpty()) {
            System.out.println("Your cart is empty.");
            return;
        }

        System.out.println("Total Amount: $" + currentOrder.calculateTotal());
        System.out.println("Select Payment Method:");
        System.out.println("1. Cash on Delivery");
        System.out.println("2. Credit Card");
        
        String payChoice = scanner.nextLine();
        PaymentMethod pm = null;

        if (payChoice.equals("1")) {
            pm = new CashOnDelivery();
        } else if (payChoice.equals("2")) {
            System.out.print("Enter Card Number: ");
            String card = scanner.nextLine();
            pm = new CreditCardPayment(card, currentUser.getUsername());
        } else {
            System.out.println("Invalid payment selection.");
            return;
        }

        // Process Payment
        boolean success = system.processPayment(currentOrder, pm);
        if (success) {
            currentOrder.setStatus("Paid & Shipped");
            system.placeOrder(currentOrder); // Save order to system history
            System.out.println("Order placed successfully! Status: " + currentOrder.getStatus());
            
            // Start a new order for next time
            currentOrder = new Order(orderIdCounter++, (Customer) currentUser);
        }
    }

    // --- SETUP DATA ---
    private static void initializeSystemData() {
        // 1. Create Users
        Customer c1 = new Customer(101, "Alice Smith", "alice@test.com","1234" ,"123 Main St", "555-0199");
        Seller s1 = new Seller(201, "Bob Builder", "bob@factory.com","admin");
        
        system.registerUser(c1);
        system.registerUser(s1);

        // 2. Create Items (Polymorphism in action)
        // Bed: ID, Name, Price, Material, Stock, Size
        FurnitureItem item1 = new Bed(1, "Luxury King Bed", 1200.00, "Oak Wood", 5, "King");
        
        // Sofa: ID, Name, Price, Material, Stock, Seats, Color
        FurnitureItem item2 = new Sofa(2, "Modern Sofa", 850.50, "Leather", 10, 3, "Black");
        
        // Table: ID, Name, Price, Material, Stock, Shape, Dimensions
        FurnitureItem item3 = new Table(3, "Dining Table", 450.00, "Glass/Metal", 8, "Rectangular", "6x4 ft" );
        
        // Add items to system
        system.addItemToSystem(item1);
        system.addItemToSystem(item2);
        system.addItemToSystem(item3);
    }
}

*/