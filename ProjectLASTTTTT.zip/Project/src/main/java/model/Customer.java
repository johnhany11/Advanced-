package model;


import java.util.ArrayList;
import java.util.List;

public class Customer extends User {
    private String address;
    private String phone;
    private List<Order> orders = new ArrayList<>();

    public Customer(int id, String name, String email, String password, String address, String phone) {
        super(id, name, email, password);
        this.address = address;
        this.phone = phone;
    }

    public boolean login(String email, String password) {
        if (getEmail().equals(email) && getPassword().equals(password)) {
            System.out.println("Login success for " + getUsername());
            return true;
        } else {
            System.out.println("Login failed for " + getUsername());
            return false;
        }
    }

    public String getRole() {
        return "CUSTOMER";
    }

    // --- Getters and Setters ---
    public String getAddress() {
        return address;
    }

    public void setAddress(String address) {
        this.address = address;
    }

    public String getPhone() {
        return phone;
    }

    public void setPhone(String phone) {
        this.phone = phone;
    }

    // --- Order Management ---
    public void placeOrder(Order order) {
        orders.add(order);
    }

    public List<Order> getOrders() {
        return orders;
    }
}