package Project;

import javafx.application.Application;
import javafx.fxml.FXMLLoader;
import javafx.scene.Scene;
import javafx.stage.Stage;

public class App extends Application {

    private static Scene scene;

    @Override
    public void start(Stage stage) throws Exception {

        scene = new Scene(
                FXMLLoader.load(getClass().getResource("Login.fxml")),
                700, 650
        );

        scene.getStylesheets().add(
                getClass().getResource("/styles/Login.css").toExternalForm()
        );

        stage.setTitle("Furniture E-Commerce System");
        stage.setScene(scene);
        stage.setMinWidth(700);
        stage.setMinHeight(650);
        stage.show();
    }

    /* =========================
       Central Scene Switching
       ========================= */
    public static void setRoot(String fxml) {
        try {
            scene.setRoot(
                    FXMLLoader.load(App.class.getResource(fxml))
            );
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

   
    public static void goToLogin(Stage stage) {
        try {
            scene.setRoot(
                    FXMLLoader.load(App.class.getResource("Login.fxml"))
            );
            stage.setTitle("Login - Furniture E-Commerce System");
            stage.setScene(scene);
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    public static void main(String[] args) {
        launch();
    }
}
