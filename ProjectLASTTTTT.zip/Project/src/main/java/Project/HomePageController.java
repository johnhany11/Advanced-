package Project;

import java.io.IOException;
import java.net.URL;
import java.util.ResourceBundle;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.fxml.Initializable;
import javafx.scene.Node;
import javafx.scene.layout.AnchorPane;
import javafx.stage.Stage;

public class HomePageController implements Initializable {

    @FXML
    private AnchorPane contentPane;

    @Override
    public void initialize(URL url, ResourceBundle rb) {
        // Optional: Load a default page (e.g., Sofa) when the app starts
        // goToSofa(null);
    }

    // UPDATED: Now accepts both the FXML file and the CSS file name
    private void loadPage(String fxml, String cssFileName) {
        try {
            // 1. Load the FXML
            AnchorPane pane = FXMLLoader.load(getClass().getResource(fxml));

            // 2. Fix Resizing: Make the new pane fill the space completely
            AnchorPane.setTopAnchor(pane, 0.0);
            AnchorPane.setBottomAnchor(pane, 0.0);
            AnchorPane.setLeftAnchor(pane, 0.0);
            AnchorPane.setRightAnchor(pane, 0.0);

            // 3. Load the CSS
            if (cssFileName != null && !cssFileName.isEmpty()) {
                // Note the "/" at the start. This tells Java to look in the root resources folder
                String cssPath = "/styles/" + cssFileName;
                URL cssUrl = getClass().getResource(cssPath);

                if (cssUrl != null) {
                    pane.getStylesheets().add(cssUrl.toExternalForm());
                } else {
                    System.err.println("Error: Could not find CSS file: " + cssPath);
                }
            }

            // 4. Display the pane
            contentPane.getChildren().setAll(pane);

        } catch (IOException e) {
            System.err.println("Error loading FXML: " + fxml);
            e.printStackTrace();
        }
    }

    @FXML
    private void goToSofa(ActionEvent event) {
        // Matches "sofapage.css" from your screenshot
        loadPage("SofaPage.fxml", "sofapage.css");
    }

    @FXML
    private void goToTable(ActionEvent event) {
        // Matches "tablepage_1.css" from your screenshot
        loadPage("TablePage.fxml", "tablepage_1.css");
    }

    @FXML
    private void goToBed(ActionEvent event) {
        // Matches "bedpage.css" from your screenshot
        loadPage("BedPage.fxml", "bedpage.css");
    }

    @FXML
    private void goToCart(ActionEvent event) {
        // Matches "cartpage.css" from your screenshot
        loadPage("CartPage.fxml", "cartpage.css");
    }

    @FXML
    private void handleLogout(ActionEvent event) {
        Stage stage = (Stage) ((Node) event.getSource())
                .getScene().getWindow();
        App.goToLogin(stage);
    }
}