package Project;

import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.fxml.Initializable;
import javafx.scene.Node;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Label;
import javafx.scene.control.Button;
import javafx.stage.Stage;

import model.Bed;
import model.CartData;
import service.FurnitureService;

import java.io.IOException;
import java.net.URL;
import java.util.List;
import java.util.ResourceBundle;

public class BedPageController implements Initializable {

    private FurnitureService furnitureService;
    private List<Bed> availableBeds;

    // --- LABELS FOR UI ---
    @FXML private Label name1;
    @FXML private Label price1;
    @FXML private Label desc1;

    @FXML private Label name2;
    @FXML private Label price2;
    @FXML private Label desc2;

    @FXML private Label name3;
    @FXML private Label price3;
    @FXML private Label desc3;

    @FXML private Button addToCart1;
    @FXML private Button addToCart2;
    @FXML private Button addToCart3;
    @FXML private Button goToCart;

    @Override
    public void initialize(URL url, ResourceBundle rb) {
        furnitureService = new FurnitureService();
        availableBeds = furnitureService.getAllBeds();

        makeResizable();
        displayBedData();

        System.out.println("Bed Controller: Loaded " + availableBeds.size() + " beds.");
    }

    // ✅ make right-side text dynamic & resizable
    private void makeResizable() {
        desc1.setWrapText(true);
        desc2.setWrapText(true);
        desc3.setWrapText(true);

        name1.setMaxWidth(Double.MAX_VALUE);
        price1.setMaxWidth(Double.MAX_VALUE);
        desc1.setMaxWidth(Double.MAX_VALUE);

        name2.setMaxWidth(Double.MAX_VALUE);
        price2.setMaxWidth(Double.MAX_VALUE);
        desc2.setMaxWidth(Double.MAX_VALUE);

        name3.setMaxWidth(Double.MAX_VALUE);
        price3.setMaxWidth(Double.MAX_VALUE);
        desc3.setMaxWidth(Double.MAX_VALUE);
    }

    private void displayBedData() {
        if (availableBeds.size() >= 1) {
            Bed b1 = availableBeds.get(0);
            name1.setText(b1.getName());
            price1.setText("$" + b1.getPrice());
            desc1.setText(b1.getDescription());
        }

        if (availableBeds.size() >= 2) {
            Bed b2 = availableBeds.get(1);
            name2.setText(b2.getName());
            price2.setText("$" + b2.getPrice());
            desc2.setText(b2.getDescription());
        }

        if (availableBeds.size() >= 3) {
            Bed b3 = availableBeds.get(2);
            name3.setText(b3.getName());
            price3.setText("$" + b3.getPrice());
            desc3.setText(b3.getDescription());
        }
    }

    @FXML
    private void addBed1() {
        if (availableBeds.size() >= 1) {
            CartData.addItem(availableBeds.get(0), 1);
        }
    }

    @FXML
    private void addBed2() {
        if (availableBeds.size() >= 2) {
            CartData.addItem(availableBeds.get(1), 1);
        }
    }

    @FXML
    private void addBed3() {
        if (availableBeds.size() >= 3) {
            CartData.addItem(availableBeds.get(2), 1);
        }
    }

    @FXML
    private void goToCart(ActionEvent event) {
        try {
            Parent root = FXMLLoader.load(getClass().getResource("CartPage.fxml"));
            Stage stage = (Stage) ((Node) event.getSource()).getScene().getWindow();
            stage.setScene(new Scene(root));
            stage.setTitle("Your Cart");
            stage.show();
        } catch (IOException e) {
            e.printStackTrace();
        }
    }
}