/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Project;

import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Node;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.stage.Stage;

public class CheckoutController {

    @FXML
    private void gotohome(ActionEvent event) {
        try {
        FXMLLoader loader = new FXMLLoader(getClass().getResource("/Project/HomePage.fxml"));

        Parent root = loader.load(); // 💥 ERROR IS HERE

        Stage stage =
            (Stage) ((Node) event.getSource()).getScene().getWindow();

        stage.setScene(new Scene(root));
        stage.show();

    } catch (Exception e) {
        e.printStackTrace(); // 🚨 THIS WILL SHOW THE REAL PROBLEM
    }
    }

    @FXML
    private void gotologin(ActionEvent event) {
                try {
        FXMLLoader loader = new FXMLLoader(getClass().getResource("/Project/Login.fxml"));

        Parent root = loader.load(); // 💥 ERROR IS HERE

        Stage stage =
            (Stage) ((Node) event.getSource()).getScene().getWindow();

        stage.setScene(new Scene(root));
        stage.show();

    } catch (Exception e) {
        e.printStackTrace(); // 🚨 THIS WILL SHOW THE REAL PROBLEM
    }
       
    }
}


    

