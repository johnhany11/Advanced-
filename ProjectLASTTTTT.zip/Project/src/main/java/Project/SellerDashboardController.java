package Project;

import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Node;
import javafx.scene.Scene;
import javafx.scene.control.ComboBox;
import javafx.scene.control.Label;
import javafx.scene.control.TextField;
import javafx.stage.Stage;

public class SellerDashboardController {

    @FXML private ComboBox<String> typeBox;
    @FXML private TextField idField;
    @FXML private TextField nameField;
    @FXML private TextField priceField;
    @FXML private TextField materialField;
    @FXML private TextField stockField;
    @FXML private Label statusLabel;

    @FXML
    private void initialize() {
        typeBox.getItems().addAll(
                "Table",
                "Sofa",
                "Bed"
        );
    }

    @FXML
    private void handleAddItem() {

        if (typeBox.getValue() == null
                || idField.getText().isEmpty()
                || nameField.getText().isEmpty()
                || priceField.getText().isEmpty()
                || stockField.getText().isEmpty()) {

            statusLabel.setText(" Please fill all fields");
            return;
        }

        try {
            Integer.parseInt(idField.getText());
            Double.parseDouble(priceField.getText());
            Integer.parseInt(stockField.getText());

            statusLabel.setText(" Item added successfully");
            clearFields();

        } catch (NumberFormatException e) {
            statusLabel.setText(" Price & Stock must be numbers");
        }
    }

    @FXML
private void handleLogout(ActionEvent event) {
    Stage stage = (Stage) ((Node) event.getSource())
            .getScene().getWindow();

    App.goToLogin(stage);
}

    private void clearFields() {
        idField.clear();
        nameField.clear();
        priceField.clear();
        materialField.clear();
        stockField.clear();
        typeBox.setValue(null);
    }
}
