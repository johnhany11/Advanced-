package service;

import dao.WarehouseDAO;
import model.FurnitureItem;
import model.Warehouse;
import java.util.List;

public class WarehouseService {

    private final WarehouseDAO warehouseDAO = new WarehouseDAO();

    // create warehouse
    public void createWarehouse(int id, String location) {
        Warehouse warehouse = new Warehouse(id, location);
        warehouseDAO.addWarehouse(warehouse);
    }

    // add item to warehouse
    public boolean addItemToWarehouse(int warehouseId, FurnitureItem item) {
        Warehouse warehouse = warehouseDAO.getWarehouseById(warehouseId);
        if (warehouse != null) {
            warehouse.addItem(item);
            return true;
        }
        return false;
    }

    // remove item from warehouse
public boolean removeItemFromWarehouse(int warehouseId, int itemId) {
    Warehouse warehouse = warehouseDAO.getWarehouseById(warehouseId);
    if (warehouse == null) {
        System.out.println("Warehouse with ID " + warehouseId + " not found.");
        return false;
    }
    if (!warehouse.checkAvailability(itemId)) {
        System.out.println("Item with ID " + itemId + " not found in warehouse.");
        return false;
    }
    warehouse.removeItem(itemId);
    System.out.println("Item with ID " + itemId + " removed successfully.");
    return true;
}


    // check item availability
    public boolean isItemAvailable(int warehouseId, int itemId) {
        Warehouse warehouse = warehouseDAO.getWarehouseById(warehouseId);
        return warehouse != null && warehouse.checkAvailability(itemId);
    }

    // get all warehouses
    public List<Warehouse> getAllWarehouses() {
        return warehouseDAO.getAllWarehouses();
    }
}
