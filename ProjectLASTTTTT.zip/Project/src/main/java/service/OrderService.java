package service;

import dao.OrderDAO;
import model.Customer;
import model.FurnitureItem;
import model.Order;
import java.util.List;

public class OrderService {
    
    // ---------------------------------------------------------
    // 1. GLOBAL ACTIVE CART (The Bridge between Pages)
    // ---------------------------------------------------------
    // "static" means this single cart is shared by ALL pages.
    private static Order activeCart; 
    
    // We also need the DAO to save the order later when we Checkout
    private OrderDAO orderDAO;

    public OrderService() {
        this.orderDAO = new OrderDAO();
    }

    /**
     * Helper method to get the current cart.
     * If no cart exists yet, it creates a new one automatically.
     */
    public static Order getActiveCart() {
        if (activeCart == null) {
            // Create a default customer (Guest) for the session
            Customer guest = new Customer(1,"Guest","guest@email.com","guest",null,null);
            activeCart = new Order(101, guest);
        }
        return activeCart;
    }

    // ---------------------------------------------------------
    // 2. STANDARD SERVICE METHODS
    // ---------------------------------------------------------

    /**
     * Adds an item to a specific order (or the active cart).
     */
    public void addItemToOrder(Order order, FurnitureItem item) {
        if (order != null && item != null) {
            order.addItem(item);
            System.out.println("Service: Added " + item.getName() + " to Cart.");
        }
    }

    /**
     * Finalizes the order and saves it to the "Database" via DAO.
     */
    public void checkout(Order order) {
        if (order.getItems().isEmpty()) {
            System.out.println("Service Error: Cannot checkout an empty order.");
            return;
        }
        
        // Calculate final total
        double total = order.calculateTotal();
        
        // DELEGATION: The Service tells the DAO to save the data
        orderDAO.saveOrder(order);
        
        // IMPORTANT: After checkout, clear the active cart so the user can start a new one!
        activeCart = null; 
        
        System.out.println("Service: Checkout complete. Total Amount: $" + total);
    }

    /**
     * Gets all orders from the database (via DAO).
     */
    public List<Order> getAllOrders() {
        return orderDAO.getAllOrders();
    }
    
    // (Optional) If you still need this for manual testing
    public Order createOrder(int newId, Customer customer) {
        return new Order(newId, customer);
    }
}