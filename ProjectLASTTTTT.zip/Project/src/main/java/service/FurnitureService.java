package service;

import java.util.Collections;
import java.util.Comparator;
import java.util.List;

import dao.FurnitureDAO;
import model.Sofa;
import model.Bed;
import model.Table;
import model.FurnitureItem; // <--- YOU MISSED THIS IMPORT

public class FurnitureService {
    
    private FurnitureDAO furnitureDAO;

    public FurnitureService() {
        this.furnitureDAO = new FurnitureDAO();
    }

    public List<Sofa> getAllSofas() {
        return furnitureDAO.getAllSofas();
    }

    public List<Bed> getAllBeds() {
        return furnitureDAO.getAllBeds();
    }

    public List<Table> getAllTables() {
        return furnitureDAO.getAllTables();
    }
    
    // Now this will work because FurnitureItem is imported!
    public <T extends FurnitureItem> void sortFurnitureByPrice(List<T> items) {
        Collections.sort(items, new Comparator<T>() {
            @Override
            public int compare(T item1, T item2) {
                return Double.compare(item1.getPrice(), item2.getPrice());
            }
        });
    }
}
























/*


package service;
import java.util.Collections;
import java.util.Comparator;
import dao.FurnitureDAO;
import model.Sofa;
import model.Bed;
import model.Table;
import java.util.List;

public class FurnitureService {
    
    private FurnitureDAO furnitureDAO;

    public FurnitureService() {
        this.furnitureDAO = new FurnitureDAO();
    }

    public List<Sofa> getAllSofas() {
        return furnitureDAO.getAllSofas();
    }

    
    public List<Bed> getAllBeds() {
        return furnitureDAO.getAllBeds();
    }

    public List<Table> getAllTables() {
        return furnitureDAO.getAllTables();
        
    }
    
    
    public <T extends FurnitureItem> void sortFurnitureByPrice(List<T> items) {
    // Uses a generic comparator to sort any list (Sofas, Beds, or Tables)
    Collections.sort(items, new Comparator<T>() {
        @Override
        public int compare(T item1, T item2) {
            // Sorts by Price (Low to High)
            return Double.compare(item1.getPrice(), item2.getPrice());
        }
    });
}
    
}

*/