package dao;

import model.Warehouse;
import java.util.ArrayList;
import java.util.List;

public class WarehouseDAO {

    private final List<Warehouse> warehouses = new ArrayList<>();

    // add warehouse
    public void addWarehouse(Warehouse warehouse) {
    if(getWarehouseById(warehouse.getWarehouseId()) == null) {
        warehouses.add(warehouse);
    }
}


    // get all warehouses
    public List<Warehouse> getAllWarehouses() {
        return warehouses;
    }

    // find warehouse by id
    public Warehouse getWarehouseById(int id) {
        for (Warehouse w : warehouses) {
            if (w.getWarehouseId() == id) {
                return w;
            }
        }
        return null;
    }

}
