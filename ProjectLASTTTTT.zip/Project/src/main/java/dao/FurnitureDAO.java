package dao;

import model.Sofa;
import model.Bed;
import model.Table;
import java.util.ArrayList;
import java.util.List;

public class FurnitureDAO {

    // --- SOFAS ---
    public List<Sofa> getAllSofas() {
        List<Sofa> list = new ArrayList<>();
        list.add(new Sofa(1, "Modern Green Sofa", 1200.0, "Velvet", 5, 3, "Green"));
        list.add(new Sofa(2, "Classic Grey Sofa", 950.0, "Fabric", 3, 2, "Grey"));
        list.add(new Sofa(3, "Luxury Red Sofa", 1500.0, "Leather", 2, 4, "Red"));
        return list;
    }

    // --- BEDS ---
    public List<Bed> getAllBeds() {
        List<Bed> list = new ArrayList<>();
        list.add(new Bed(4, "King Size Bed", 2000.0, "Wood", 2, "King"));
        list.add(new Bed(5, "Queen Size Bed", 1500.0, "Metal", 4, "Queen"));
        list.add(new Bed(6, "Single Bed", 800.0, "Wood", 6, "Single"));
        return list;
    }

    // --- TABLES (Fixed) ---
    public List<Table> getAllTables() {
        List<Table> list = new ArrayList<>();
        
        // ADDED image paths to match the new Table constructor
        list.add(new Table(7, "Dining Table", 600.0, "Glass", 3, "Round", "120x120")); 
        list.add(new Table(8, "Coffee Table", 300.0, "Wood", 5, "Square", "60x60"));
        list.add(new Table(9, "Office Desk", 450.0, "Metal", 2, "Rectangle", "140x80"));
        
        return list;
    }
}