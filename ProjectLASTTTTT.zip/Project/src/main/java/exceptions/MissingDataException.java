
package exceptions;

public class MissingDataException extends Exception {
    public MissingDataException(String message) {
        super(message);
    }
}
