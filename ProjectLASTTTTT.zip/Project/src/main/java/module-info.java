module Project {
    requires javafx.controls;
    requires javafx.fxml;

    // Open the package "Project" to FXML
    opens Project to javafx.fxml;

    // Export the package "Project"
    exports Project;
    exports exceptions;
}