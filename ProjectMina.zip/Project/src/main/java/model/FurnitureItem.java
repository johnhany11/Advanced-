package model;

public abstract class FurnitureItem implements Comparable<FurnitureItem> {

    protected int itemId;
    protected String name;
    protected double price;
    protected String material;
    protected int stock;
    
    // --- ADDED THIS ---
    protected String imagePath; 

    // Updated Constructor to include imagePath
    public FurnitureItem(int itemId, String name, double price, String material, int stock, String imagePath) {
        this.itemId = itemId;
        this.name = name;
        this.price = price;
        this.material = material;
        this.stock = stock;
        this.imagePath = imagePath;
    }

    public double getPrice() {
        return price;
    }

    public void updateStock(int qty) {
        this.stock += qty;
    }

    @Override
    public int compareTo(FurnitureItem other) {
        return Double.compare(this.price, other.price);
    }

    // Getters
    public int getItemId() { return itemId; }
    public String getName() { return name; }
    public int getStock() { return stock; }
    public String getMaterial() { return material; }
    
    // --- ADDED GETTER ---
    public String getImagePath() { return imagePath; }

    // Abstract method: Forces Sofa/Bed to define their own description
    public abstract String getDescription(); 
}