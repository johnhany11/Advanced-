package model;

import java.util.ArrayList;
import java.util.List;

public class Customer extends User {
    private String address;
    private String phone;
    // Uncommenting this requires an 'Order' class to exist in the model package
    private List<Order> orders = new ArrayList<>(); 

    public Customer(int userId, String name, String email) {
        super(userId, name, email);
        this.address = address;
        this.phone = phone;
    }

    @Override
    public boolean login(String email, String password) {
        // Simple validation logic
        if (this.email.equals(email)) {
            System.out.println("Login success for " + name);
            return true;
        } else {
            System.out.println("Login failed for " + name);
            return false;
        }
    }

    // --- Getters and Setters ---
    public String getAddress() {
        return address;
    }

    public void setAddress(String address) {
        this.address = address;
    }

    public String getPhone() {
        return phone;
    }

    public void setPhone(String phone) {
        this.phone = phone;
    }

    // --- Order Management ---
    public void placeOrder(Order order) {
        orders.add(order);
    }

    public List<Order> getOrders() {
        return orders;
    }
}