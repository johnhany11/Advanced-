package model;

public class Table extends FurnitureItem {

    private String shape;
    private String dimensions;

    // FIX: Added 'String imagePath' to the arguments here
    public Table(int itemid, String name, double price, String material, 
                 int stock, String shape, String dimensions, String imagePath) {

        // Now 'imagePath' exists, so we can pass it to the parent
        super(itemid, name, price, material, stock, imagePath); 
        this.shape = shape;
        this.dimensions = dimensions;
    }

    public String getShape() { return shape; }
    public String getDimensions() { return dimensions; }

    @Override
    public String toString() {
        return super.toString() + ", Shape: " + shape;
    }

    @Override
    public String getDescription() {
        return "Shape: " + shape + ", Dimensions: " + dimensions;
    }
}