package model;


import java.util.ArrayList;
import java.util.List;

public class Warehouse {

    private int warehouseId;
    private String location;
    private List<FurnitureItem> inventory;

    public Warehouse(int warehouseId, String location) {
        this.warehouseId = warehouseId;
        this.location = location;
        this.inventory = new ArrayList<>();
    }

    public void addItem(FurnitureItem item) {
        inventory.add(item);
    }

    public void removeItem(int id) {
        inventory.removeIf(item -> item.getItemId() == id);
    }

    public boolean checkAvailability(int id) {
        return inventory.stream().anyMatch(item -> item.getItemId() == id);
    }

    // Optional getters/setters if needed
    public int getWarehouseId() { return warehouseId; }
    public String getLocation() { return location; }
    public List<FurnitureItem> getInventory() { return inventory; }
}
