package model;


public class CashOnDelivery implements PaymentMethod {

    @Override
    public boolean pay(double amount) {
        System.out.println("Cash on Delivery selected.");
        return true;
    }
}

