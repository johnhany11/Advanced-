package Project;

import java.net.URL;
import java.util.ResourceBundle;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.Initializable;
import javafx.geometry.Pos;
import javafx.scene.Cursor;
import javafx.scene.Scene;
import javafx.scene.control.Label;
import javafx.scene.control.ListView;
import javafx.scene.control.RadioButton;
import javafx.scene.control.TextField;
import javafx.scene.layout.VBox;
import javafx.scene.paint.Color;
import javafx.scene.text.Font;
import javafx.stage.Stage;
import model.CartData;
import model.CartItem;

public class CartPageController implements Initializable {

    // --- FXML IDs (Must match your Scene Builder) ---
    @FXML private ListView<String> cartList;
    @FXML private Label totalAmountLabel;
    @FXML private RadioButton codRadio;
    @FXML private RadioButton visaRadio;
    @FXML private TextField cardNumberField;
    @FXML private TextField holderNameField;
    @FXML private Label statusLabel;

    @Override
    public void initialize(URL url, ResourceBundle rb) {
        // 1. Load the items when the screen opens
        loadCartItems();
    }

    // --- Helper Method to Load Data ---
    private void loadCartItems() {
        cartList.getItems().clear();
        
        // Loop through the static CartData and add to list
        for (CartItem item : CartData.getItems()) {
            cartList.getItems().add(item.toString());
        }
        
        // Calculate and display total
        totalAmountLabel.setText("Total Amount: $" + CartData.getTotalAmount());
    }

    // --- Payment Logic (From the code you just sent) ---

    @FXML
    private void handleCOD(ActionEvent event) {
        // Disable and clear card fields for Cash on Delivery
        cardNumberField.setDisable(true);
        holderNameField.setDisable(true);
        cardNumberField.clear();
        holderNameField.clear();
        statusLabel.setText(""); // Clear error message
    }

    @FXML
    private void handleVisa(ActionEvent event) {
        // Enable fields for Visa
        cardNumberField.setDisable(false);
        holderNameField.setDisable(false);
        statusLabel.setText(""); 
    }

    @FXML
    private void handleConfirm(ActionEvent event) {
        // 1. Validation Logic
        if (visaRadio.isSelected()) {
            if (cardNumberField.getText().isEmpty() || holderNameField.getText().isEmpty()) {
                statusLabel.setText("Please fill card details");
                statusLabel.setTextFill(Color.RED);
                return;
            }
        }

        // 2. Clear Cart Logic (Optional: Clear the data since they bought it)
        CartData.getItems().clear();

        // 3. Success Screen Logic
        showSuccessScreen();
    }

    // --- Helper to Create the Success Scene ---
    private void showSuccessScreen() {
        // Success label
        Label successLabel = new Label("Order successfully purchased!");
        successLabel.setFont(Font.font(20));

        // Home label (acts like a button)
        Label homeLabel = new Label("Home");
        homeLabel.setTextFill(Color.BLUE);
        homeLabel.setUnderline(true);
        homeLabel.setCursor(Cursor.HAND);
        
        // Add click event for Home (You can link this to load HomePage.fxml later)
        homeLabel.setOnMouseClicked(e -> System.out.println("Go to Home..."));

        // Logout label
        Label logoutLabel = new Label("Logout");
        logoutLabel.setTextFill(Color.RED);
        logoutLabel.setUnderline(true);
        logoutLabel.setCursor(Cursor.HAND);
        
        // Add click event for Logout
        logoutLabel.setOnMouseClicked(e -> System.out.println("Logging out..."));

        // Layout
        VBox root = new VBox(20, successLabel, homeLabel, logoutLabel);
        root.setAlignment(Pos.CENTER);

        // Switch Scene
        Scene successScene = new Scene(root, 400, 250);
        Stage stage = (Stage) statusLabel.getScene().getWindow();
        stage.setScene(successScene);
    }
}