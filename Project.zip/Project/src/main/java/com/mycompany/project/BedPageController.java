package com.mycompany.project;

//import Cart.CartData;
//import Cart.CartItem;
import java.io.IOException;
import java.net.URL;
import java.util.ResourceBundle;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.fxml.Initializable;
import javafx.scene.Node;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.stage.Stage;

public class BedPageController implements Initializable {

    @FXML private Button addToCart1;
    @FXML private Button addToCart2;
    @FXML private Button addToCart3;
    @FXML private Button goToCart;

    @Override
    public void initialize(URL url, ResourceBundle rb) {
        // Nothing to initialize
    }

    @FXML
    private void addBed1() {
        //CartData.addItem(new CartItem("Modern King Bed"));
        System.out.println("Modern King Bed added to cart");
    }

    @FXML
    private void addBed2() {
      //  CartData.addItem(new CartItem("Classic Queen Bed"));
        System.out.println("Classic Queen Bed added to cart");
    }

    @FXML
    private void addBed3() {
       // CartData.addItem(new CartItem("Luxury Single Bed"));
        System.out.println("Luxury Single Bed added to cart");
    }

    @FXML
    private void goToCart(ActionEvent event) {
        try {
            Parent root = FXMLLoader.load(getClass().getResource("CartPage.fxml"));
            Stage stage = (Stage) ((Node) event.getSource()).getScene().getWindow();
            stage.setScene(new Scene(root));
            stage.setTitle("Cart");
            stage.show();
        } catch (IOException e) {
            e.printStackTrace();
        }
    }
}