package com.mycompany.project;

import javafx.application.Application;
import javafx.fxml.FXMLLoader;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.stage.Stage;
import java.util.Objects;

public class App extends Application {

    @Override
    public void start(Stage primaryStage) {
        try {
            // Correct path: Looks in the same package as App.java
            Parent root = FXMLLoader.load(Objects.requireNonNull(getClass().getResource("Login.fxml")));
            
            Scene scene = new Scene(root);
            
            // Correct path: Looks at the root of the resources folder
            String css = Objects.requireNonNull(getClass().getResource("/styles/Login.css")).toExternalForm();
            
            scene.getStylesheets().add(css);
            primaryStage.setTitle("Furniture E-Commerce System");
            primaryStage.setScene(scene);
            primaryStage.show();
        } 
        catch (Exception e) {
            e.printStackTrace();
        }
    }

    public static void main(String[] args) {
        launch();
    }
}