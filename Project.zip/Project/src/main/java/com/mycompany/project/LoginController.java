
package com.mycompany.project;

import java.io.IOException;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Node;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Label;
import javafx.scene.control.PasswordField;
import javafx.scene.control.TextField;
import javafx.stage.Stage;

// IMPORT YOUR PROJECT1 CLASSES
import model.Customer;

public class LoginController {

    @FXML
    private TextField usernameField; // This acts as the email input
    
    @FXML
    private PasswordField passwordField;
    
    @FXML
    private Label errorLabel;

    // --- STEP 1: CREATE A TEST CUSTOMER ---
    // We create one user in memory to test the system.
    // Email: "mario@test.com"
    
    
    
    private final Customer systemUser = new Customer(1, "Mina", "Mina", "Cairo", "0100000000");
    
    
    @FXML
    private void handleLogin(ActionEvent event) {
        String emailInput = usernameField.getText();
        String passInput = passwordField.getText();

        // --- STEP 2: CONNECT TO YOUR BACKEND LOGIC ---
        // We strictly use your Customer.login() method.
        // As you requested, we do NOT add extra password checks here.
        boolean isAuthorized = systemUser.login(emailInput, passInput);
        
        if (isAuthorized) {
            // Your Customer class printed "Login success...", now we move the screen.
            System.out.println("Controller: User authorized. Switching scenes.");
            switchToMainPage(event);
        } else {
            errorLabel.setText("Invalid Email (Must be Mina)");
            System.out.println("Controller: Login Failed.");
        }
    }

    private void switchToMainPage(ActionEvent event) {
        try {
            
            Parent root = FXMLLoader.load(getClass().getResource("HomePage.fxml"));
            Stage stage = (Stage) ((Node) event.getSource()).getScene().getWindow();
            Scene scene = new Scene(root);
            
            stage.setScene(scene);
            stage.show();
        } catch (IOException e) {
            e.printStackTrace();
            errorLabel.setText("Error: Could not find HomePage.fxml");
        }
    }
}