package com.mycompany.project;

//import Cart.CartData;
//import Cart.CartItem;
import java.io.IOException;
import java.net.URL;
import java.util.ResourceBundle;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.fxml.Initializable;
import javafx.scene.Node;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.stage.Stage;

public class SofaPageController implements Initializable {

    @FXML private Button addToCart;
    @FXML private Button addToCart2;
    @FXML private Button addToCart3;
    @FXML private Button goToCart;

    @Override
    public void initialize(URL url, ResourceBundle rb) {
        // Nothing to initialize for now
    }

    @FXML
    private void addSofa1() {
     //   CartData.addItem(new CartItem("Modern Green Sofa"));
        System.out.println("Modern Green Sofa added to cart");
    }

    @FXML
    private void addSofa2() {
      //  CartData.addItem(new CartItem("Classic Grey Sofa"));
        System.out.println("Classic Grey Sofa added to cart");
    }

    @FXML
    private void addSofa3() {
       // CartData.addItem(new CartItem("Luxury Burgundy Sofa"));
        System.out.println("Luxury Burgundy Sofa added to cart");
    }

    @FXML
    private void goToCart(ActionEvent event) {
        try {
            Parent root = FXMLLoader.load(getClass().getResource("CartPage.fxml"));
            Stage stage = (Stage) ((Node) event.getSource()).getScene().getWindow();
            stage.setScene(new Scene(root));
            stage.setTitle("Cart");
            stage.show();
        } catch (IOException e) {
            e.printStackTrace();
        }
    }
}