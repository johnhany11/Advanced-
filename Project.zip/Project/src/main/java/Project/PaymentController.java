package Project;
//package cart;
import java.net.URL;
import java.util.ResourceBundle;
import javafx.fxml.Initializable;

import javafx.fxml.FXML;
import javafx.scene.control.Label;
import javafx.scene.control.RadioButton;
import javafx.scene.control.TextField;
import javafx.scene.control.Alert;
import javafx.scene.control.Alert.AlertType;
import javafx.stage.Stage;
import javafx.scene.Scene;
import javafx.scene.layout.VBox;
import javafx.scene.control.Label;
import javafx.scene.paint.Color;
import javafx.scene.text.Font;
import javafx.stage.Stage;
import javafx.geometry.Pos;
import javafx.scene.Cursor;



public class PaymentController {

    @FXML private RadioButton codRadio;
    @FXML private RadioButton visaRadio;
    @FXML private TextField cardNumberField;
    @FXML private TextField holderNameField;
    @FXML private Label statusLabel;

    @FXML
    private void handleCOD() {
        cardNumberField.setDisable(true);
        holderNameField.setDisable(true);

        cardNumberField.clear();
        holderNameField.clear();


    }

    @FXML
    private void handleVisa() {
        cardNumberField.setDisable(false);
        holderNameField.setDisable(false);

        statusLabel.setText("");
    }

@FXML
private void handleConfirm() {

    if (visaRadio.isSelected()) {
        if (cardNumberField.getText().isEmpty() || holderNameField.getText().isEmpty()) {
            statusLabel.setText("Please fill card details");
            return;
        }
    }

    // Success label
    Label successLabel = new Label("Order successfully purchased!");
    successLabel.setFont(Font.font(20));

    // Home label (acts like a button)
    Label homeLabel = new Label("Home");
    homeLabel.setTextFill(Color.BLUE);
    homeLabel.setUnderline(true);
    homeLabel.setCursor(Cursor.HAND);

    // Logout label (acts like a button)
    Label logoutLabel = new Label("Logout");
    logoutLabel.setTextFill(Color.RED);
    logoutLabel.setUnderline(true);
    logoutLabel.setCursor(Cursor.HAND);

    // Click actions
  

    VBox root = new VBox(20, successLabel, homeLabel, logoutLabel);
    root.setAlignment(Pos.CENTER);

    Scene successScene = new Scene(root, 400, 250);

    Stage stage = (Stage) statusLabel.getScene().getWindow();
    stage.setScene(successScene);
}

}

