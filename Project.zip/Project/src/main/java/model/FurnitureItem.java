package model;


public abstract class FurnitureItem implements Comparable<FurnitureItem> {

    protected int itemId;
    protected String name;
    protected double price;
    protected String material;
    protected int stock;

    public FurnitureItem(int itemId, String name, double price, String material, int stock) {
        this.itemId = itemId;
        this.name = name;
        this.price = price;
        this.material = material;
        this.stock = stock;
    }

    public double getPrice() {
        return price;
    }

    public void updateStock(int qty) {
        this.stock += qty;
    }

    @Override
    public int compareTo(FurnitureItem other) {
        // Sort by price
        return Double.compare(this.price, other.price);
    }

    // Optional: getters
    public int getItemId() { return itemId; }
    public String getName() { return name; }
    public int getStock() { return stock; }
    public String getMaterial() { return material; }

    Object getDescription() {
        throw new UnsupportedOperationException("Not supported yet."); // Generated from nbfs://nbhost/SystemFileSystem/Templates/Classes/Code/GeneratedMethodBody
    }
}

    
    
