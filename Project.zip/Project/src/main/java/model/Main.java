package model;

import java.util.Scanner;
import java.util.List;

public class Main {
    // Scanner for reading input
    private static Scanner scanner = new Scanner(System.in);
    private static ECommerceSystem system = new ECommerceSystem();
    private static User currentUser = null;
    private static Order currentOrder = null;
    private static int orderIdCounter = 1;

    public static void main(String[] args) {
        // 1. Setup Dummy Data (Database simulation)
        initializeSystemData();

        System.out.println("=========================================");
        System.out.println("   Welcome to Furniture E-Commerce App   ");
        System.out.println("=========================================");

        boolean running = true;
        while (running) {
            if (currentUser == null) {
                showLoginMenu();
            } else {
                showCustomerMenu();
            }
        }
    }

    // --- MENUS ---

    private static void showLoginMenu() {
        System.out.println("\n--- LOGIN ---");
        System.out.print("Enter Email (try 'alice@test.com'): ");
        String email = scanner.nextLine();
        // Simple password simulation
        System.out.print("Enter Password (any): ");
        String password = scanner.nextLine();

        // Find user in system
        for (User u : system.getUsers()) {
            if (u.getEmail().equalsIgnoreCase(email)) {
                if (u.login(email, password)) {
                    currentUser = u;
                    // Initialize a new order for this session
                    if (currentUser instanceof Customer) {
                        currentOrder = new Order(orderIdCounter++, (Customer) currentUser);
                    }
                    return;
                }
            }
        }
        System.out.println("User not found or login failed.");
    }

    private static void showCustomerMenu() {
        System.out.println("\n--- MAIN MENU (" + currentUser.getName() + ") ---");
        System.out.println("1. View All Items (Sorted by Price)");
        System.out.println("2. Search Items");
        System.out.println("3. Add Item to Order");
        System.out.println("4. View Cart & Checkout");
        System.out.println("5. Logout");
        System.out.print("Choose option: ");

        String choice = scanner.nextLine();
        switch (choice) {
            case "1":
                viewSortedItems();
                break;
            case "2":
                searchForItems();
                break;
            case "3":
                addToCart();
                break;
            case "4":
                checkout();
                break;
            case "5":
                currentUser.logout();
                currentUser = null;
                currentOrder = null;
                break;
            default:
                System.out.println("Invalid option.");
        }
    }

    // --- ACTIONS ---

    private static void viewSortedItems() {
        System.out.println("\n--- Available Furniture (Low to High Price) ---");
        // Sort items using the Comparable implementation you wrote
        system.sortItems();
        
        List<FurnitureItem> items = system.getAllItems();
        for (FurnitureItem item : items) {
            System.out.println("ID: " + item.getItemId() + " | " + item.toString() + " | Price: $" + item.getPrice());
        }
    }

    private static void searchForItems() {
        System.out.print("Enter keyword (e.g., 'Wood', 'King', 'Office'): ");
        String keyword = scanner.nextLine();
        
        // This relies on the fix we made in ECommerceSystem (using getMaterial instead of description)
        List<FurnitureItem> results = system.searchItems(keyword);
        
        if (results.isEmpty()) {
            System.out.println("No items found.");
        } else {
            for (FurnitureItem item : results) {
                System.out.println("Found: " + item.getName() + " - " + item.getMaterial() + " ($" + item.getPrice() + ")");
            }
        }
    }

    private static void addToCart() {
        System.out.print("Enter Item ID to buy: ");
        try {
            int id = Integer.parseInt(scanner.nextLine());
            // Find the item manually for this test
            FurnitureItem selected = null;
            for (FurnitureItem item : system.getAllItems()) {
                if (item.getItemId() == id) {
                    selected = item;
                    break;
                }
            }

            if (selected != null) {
                currentOrder.addItem(selected);
                System.out.println(selected.getName() + " added to your cart.");
            } else {
                System.out.println("Item ID not found.");
            }
        } catch (NumberFormatException e) {
            System.out.println("Invalid ID format.");
        }
    }

    private static void checkout() {
        System.out.println("\n--- CHECKOUT ---");
        if (currentOrder.getItems().isEmpty()) {
            System.out.println("Your cart is empty.");
            return;
        }

        System.out.println("Total Amount: $" + currentOrder.calculateTotal());
        System.out.println("Select Payment Method:");
        System.out.println("1. Cash on Delivery");
        System.out.println("2. Credit Card");
        
        String payChoice = scanner.nextLine();
        PaymentMethod pm = null;

        if (payChoice.equals("1")) {
            pm = new CashOnDelivery();
        } else if (payChoice.equals("2")) {
            System.out.print("Enter Card Number: ");
            String card = scanner.nextLine();
            pm = new CreditCardPayment(card, currentUser.getName());
        } else {
            System.out.println("Invalid payment selection.");
            return;
        }

        // Process Payment
        boolean success = system.processPayment(currentOrder, pm);
        if (success) {
            currentOrder.setStatus("Paid & Shipped");
            system.placeOrder(currentOrder); // Save order to system history
            System.out.println("Order placed successfully! Status: " + currentOrder.getStatus());
            
            // Start a new order for next time
            currentOrder = new Order(orderIdCounter++, (Customer) currentUser);
        }
    }

    // --- SETUP DATA ---
    private static void initializeSystemData() {
        // 1. Create Users
        Customer c1 = new Customer(101, "Alice Smith", "alice@test.com", "123 Main St", "555-0199");
        Seller s1 = new Seller(201, "Bob Builder", "bob@factory.com");
        
        system.registerUser(c1);
        system.registerUser(s1);

        // 2. Create Items (Polymorphism in action)
        // Bed: ID, Name, Price, Material, Stock, Size
        FurnitureItem item1 = new Bed(1, "Luxury King Bed", 1200.00, "Oak Wood", 5, "King");
        
        // Sofa: ID, Name, Price, Material, Stock, Seats, Color
        FurnitureItem item2 = new Sofa(2, "Modern Sofa", 850.50, "Leather", 10, 3, "Black");
        
        // Table: ID, Name, Price, Material, Stock, Shape, Dimensions
        FurnitureItem item3 = new Table(3, "Dining Table", 450.00, "Glass/Metal", 8, "Rectangular", "6x4 ft");
        
        // Add items to system
        system.addItemToSystem(item1);
        system.addItemToSystem(item2);
        system.addItemToSystem(item3);
    }
}