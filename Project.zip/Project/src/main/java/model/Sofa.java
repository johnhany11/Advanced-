package model;


public class Sofa extends FurnitureItem {

    private int seats;
    private String color;

    public Sofa(int itemid, String name, double price, String material,
                int stock, int seats, String color) {

        super(itemid, name, price, material, stock);
        this.seats = seats;
        this.color = color;
    }

    public int getSeats() {
        return seats;
    }

    public String getColor() {
        return color;
    }

    @Override
    public String toString() {
        return super.toString() + ", Seats: " + seats + ", Color: " + color;
    }
}
