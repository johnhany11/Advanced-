package project1;


public interface PaymentMethod {
    boolean pay(double amount);
}
