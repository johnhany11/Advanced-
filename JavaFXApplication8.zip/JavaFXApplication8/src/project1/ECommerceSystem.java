package project1;


import java.util.ArrayList;
import java.util.Comparator;
import java.util.List;
import java.util.stream.Collectors;

public class ECommerceSystem {

    private List<User> users;
    private List<Warehouse> warehouses;
    private List<Order> orders;
    private List<FurnitureItem> allItems;

    public ECommerceSystem() {
        this.users = new ArrayList<>();
        this.warehouses = new ArrayList<>();
        this.orders = new ArrayList<>();
        this.allItems = new ArrayList<>();
    }

    public void registerUser(User user) {
        users.add(user);
    }

   public List<FurnitureItem> searchItems(String keyword) {
    String key = keyword.toLowerCase();
    return allItems.stream()
            .filter(item -> 
                    // Search in Name OR Material (since description doesn't exist)
                    item.getName().toLowerCase().contains(key) || 
                    item.getMaterial().toLowerCase().contains(key)) 
            .collect(Collectors.toList());
}

    public void sortItems() {
        allItems.sort(Comparator.comparing(FurnitureItem::getPrice));
    }

    public void placeOrder(Order order) {
        orders.add(order);
    }

    public boolean processPayment(Order order, PaymentMethod p) {
        return p.pay(order.calculateTotal());
    }

    // Optional: add items globally
    public void addItemToSystem(FurnitureItem item) {
        allItems.add(item);
    }

    // Optional getters if needed
    public List<User> getUsers() { return users; }
    public List<Warehouse> getWarehouses() { return warehouses; }
    public List<Order> getOrders() { return orders; }
    public List<FurnitureItem> getAllItems() { return allItems; }
}

