package project1;


import java.util.ArrayList;
import java.util.List;

public class Order {

    private int orderId;
    private Customer customer;
    private List<FurnitureItem> items;
    private double totalPrice;
    private String status; // Pending, Shipped, Delivered

    public Order(int orderId, Customer customer) {
        this.orderId = orderId;
        this.customer = customer;
        this.items = new ArrayList<>();
        this.status = "Pending";
    }

    public double calculateTotal() {
        totalPrice = items.stream()
                          .mapToDouble(FurnitureItem::getPrice)
                          .sum();
        return totalPrice;
    }

    public void addItem(FurnitureItem item) {
        items.add(item);
        calculateTotal();
    }

    public void removeItem(int id) {
        items.removeIf(item -> item.getItemId() == id);
        calculateTotal();
    }

    // Optional getters/setters
    public int getOrderId() { return orderId; }
    public Customer getCustomer() { return customer; }
    public List<FurnitureItem> getItems() { return items; }
    public String getStatus() { return status; }
    public void setStatus(String status) { this.status = status; }
}
