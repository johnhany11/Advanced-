package model;

public class Sofa extends FurnitureItem {
    private int seats;
    private String color;

    // UPDATE: Added 'imagePath' to the end of the constructor
    public Sofa(int itemId, String name, double price, String material, int stock, int seats, String color, String imagePath) {
        
        // Pass imagePath to the parent (FurnitureItem)
        super(itemId, name, price, material, stock, imagePath);
        
        this.seats = seats;
        this.color = color;
    }

    public int getSeats() {
        return seats;
    }

    public String getColor() {
        return color;
    }

    @Override
    public String getDescription() {
        return "Color: " + color + ", Seats: " + seats;
    }
    
    @Override
    public String toString() {
        return super.toString() + " - " + color;
    }
}