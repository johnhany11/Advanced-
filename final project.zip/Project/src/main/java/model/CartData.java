
package model;



import java.util.ArrayList;
import java.util.List;

public class CartData {
    // The list that holds your cart items globally
    private static List<CartItem> items = new ArrayList<>();

    public static void addItem(FurnitureItem furniture, int quantity) {
        // Logic: if item exists, just update quantity, otherwise add new
        items.add(new CartItem(furniture, quantity));
    }

    public static List<CartItem> getItems() {
        return items;
    }
    
    public static double getTotalAmount() {
        double total = 0;
        for (CartItem item : items) {
            total += (item.getFurniture().getPrice() * item.getQuantity());
        }
        return total;
    }
}