package model;

public class Bed extends FurnitureItem {
    private String size;

    // UPDATE: Added 'imagePath' to the constructor
    public Bed(int itemid, String name, double price, String material, int stock, String size, String imagePath) {

        // Pass imagePath to the parent (FurnitureItem)
        super(itemid, name, price, material, stock, imagePath);
        this.size = size;
    }

    public String getSize() {
        return size;
    }
    
    // Abstract method implementation (required by FurnitureItem)
    @Override
    public String getDescription() {
        return "Size: " + size + ", Material: " + getMaterial();
    }

    @Override
    public String toString() {
        return super.toString() + ", Size: " + size;
    }
}