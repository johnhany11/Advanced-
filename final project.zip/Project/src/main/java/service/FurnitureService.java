package service;

import dao.FurnitureDAO;
import model.Sofa;
import model.Bed;
import model.Table;
import java.util.List;

public class FurnitureService {
    
    private FurnitureDAO furnitureDAO;

    public FurnitureService() {
        this.furnitureDAO = new FurnitureDAO();
    }

    public List<Sofa> getAllSofas() {
        return furnitureDAO.getAllSofas();
    }

    // --- NEW METHODS ---
    public List<Bed> getAllBeds() {
        return furnitureDAO.getAllBeds();
    }

    public List<Table> getAllTables() {
        return furnitureDAO.getAllTables();
    }
}