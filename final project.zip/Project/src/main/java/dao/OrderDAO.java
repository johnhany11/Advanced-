/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package dao;

import model.Order;
import java.util.ArrayList;
import java.util.List;

/**
 *
 * @author LENOVO
 */
public class OrderDAO {

    // 1. Static List to simulate a Database Table for Orders
    // We use 'static' so the data survives even if you switch pages
    private static List<Order> orderDatabase = new ArrayList<>();

    // 2. SAVE Method (Simulates 'INSERT INTO orders...')
    public void saveOrder(Order order) {
        orderDatabase.add(order);
        System.out.println("DAO: Order saved successfully! Total orders: " + orderDatabase.size());
    }

    // 3. READ Method (Simulates 'SELECT * FROM orders')
    // Used for the Seller Dashboard to see what people bought
    public List<Order> getAllOrders() {
        return orderDatabase;
    }
}