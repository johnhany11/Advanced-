package Project;

import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.*;
import javafx.stage.Stage;
import model.User;
import service.UserService;

public class LoginController {

    @FXML private TextField usernameField;
    @FXML private PasswordField passwordField;
    @FXML private Label errorLabel;

    private final UserService userService = new UserService();

    @FXML
    private void handleLogin() {

        User user = userService.login(
                usernameField.getText(),
                passwordField.getText()
        );

        if (user == null) {
            errorLabel.setText("Invalid username or password");
            return;
        }

        try {
            // 🔹 Open dashboard in NEW window
            Parent root;
            if ("CUSTOMER".equals(user.getRole())) {
                root = FXMLLoader.load(getClass().getResource("HomePage.fxml"));
            } else {
                root = FXMLLoader.load(getClass().getResource("SellerDashboard.fxml"));
            }

            Stage dashboardStage = new Stage();
            dashboardStage.setTitle("Dashboard");
            dashboardStage.setScene(new Scene(root, 800, 600));
            dashboardStage.show();

            // 🔹 Close login window
            ((Stage) usernameField.getScene().getWindow()).close();

        } catch (Exception e) {
            e.printStackTrace();
            errorLabel.setText("Could not load dashboard");
        }
    }

    @FXML
    private void goToRegister() {
        // 🔹 Switch scene ONLY (same window)
        App.setRoot("Register.fxml");
    }
}
