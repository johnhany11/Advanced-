package Project;

import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.fxml.Initializable;
import javafx.scene.Node;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.Label; // Import Label
import javafx.stage.Stage;

import model.Table;         
import model.CartData;      
import service.FurnitureService; 

import java.io.IOException;
import java.net.URL;
import java.util.List;
import java.util.ResourceBundle;

public class TablePageController implements Initializable {

    // --- BUTTONS ---
    @FXML private Button addToCart1;
    @FXML private Button addToCart2;
    @FXML private Button addToCart3;
    @FXML private Button goToCart;

    // --- LABELS FOR UI ---
    // Table 1
    @FXML private Label name1;
    @FXML private Label price1;
    @FXML private Label desc1;

    // Table 2
    @FXML private Label name2;
    @FXML private Label price2;
    @FXML private Label desc2;

    // Table 3
    @FXML private Label name3;
    @FXML private Label price3;
    @FXML private Label desc3;

    private FurnitureService furnitureService;
    private List<Table> availableTables;

    @Override
    public void initialize(URL url, ResourceBundle rb) {
        furnitureService = new FurnitureService();
        
        // 1. Load Tables from Database
        availableTables = furnitureService.getAllTables();
        
        // 2. Display Data on Labels
        displayTableData();
        
        System.out.println("Table Controller: Loaded " + availableTables.size() + " tables.");
    }

    private void displayTableData() {
        // --- Table 1 ---
        if (availableTables.size() >= 1) {
            Table t1 = availableTables.get(0);
            name1.setText(t1.getName());
            price1.setText("$" + t1.getPrice());
            desc1.setText(t1.getDescription());
        }

        // --- Table 2 ---
        if (availableTables.size() >= 2) {
            Table t2 = availableTables.get(1);
            name2.setText(t2.getName());
            price2.setText("$" + t2.getPrice());
            desc2.setText(t2.getDescription());
        }

        // --- Table 3 ---
        if (availableTables.size() >= 3) {
            Table t3 = availableTables.get(2);
            name3.setText(t3.getName());
            price3.setText("$" + t3.getPrice());
            desc3.setText(t3.getDescription());
        }
    }

    // --- BUTTON ACTIONS ---

    @FXML
    private void addTable1() {
        if (availableTables.size() >= 1) {
            CartData.addItem(availableTables.get(0), 1);
            System.out.println("Added to Cart: " + availableTables.get(0).getName());
        }
    }

    @FXML
    private void addTable2() {
        if (availableTables.size() >= 2) {
            CartData.addItem(availableTables.get(1), 1);
            System.out.println("Added to Cart: " + availableTables.get(1).getName());
        }
    }

    @FXML
    private void addTable3() {
        if (availableTables.size() >= 3) {
            CartData.addItem(availableTables.get(2), 1);
            System.out.println("Added to Cart: " + availableTables.get(2).getName());
        }
    }

    @FXML
    private void goToCart(ActionEvent event) {
        try {
            Parent root = FXMLLoader.load(getClass().getResource("CartPage.fxml"));
            Stage stage = (Stage) ((Node) event.getSource()).getScene().getWindow();
            stage.setScene(new Scene(root));
            stage.setTitle("Your Cart");
            stage.show();
        } catch (IOException e) {
            e.printStackTrace();
            System.out.println("Error loading CartPage.fxml");
        }
    }
}