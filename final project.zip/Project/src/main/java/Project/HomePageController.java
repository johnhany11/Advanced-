/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/javafx/FXMLController.java to edit this template
 */
package Project;

import java.io.IOException;
import java.net.URL;
import java.util.ResourceBundle;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.fxml.Initializable;
import javafx.scene.Node;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.stage.Stage;

/**
 * FXML Controller class
 *
 * @author LENOVO
 */
public class HomePageController implements Initializable {
    
@FXML private Button sofaButton;
@FXML private Button bedButton;
@FXML private Button cartButton;
@FXML private Button tableButton;
@FXML private Button logoutButton;
    
@FXML
private void handleLogout(ActionEvent event) {
    try {



        // Load the Login.fxml

        Parent root = FXMLLoader.load(getClass().getResource("Login.fxml"));

        // Get current stage from the event source
        Stage stage = (Stage) ((Node) event.getSource()).getScene().getWindow();
        // Set the new scene
        Scene scene = new Scene(root);
        String css = this.getClass().getResource("/styles/Login.css").toExternalForm();

        scene.getStylesheets().add(css);

        stage.setScene(scene);

        stage.setTitle("Login - Furniture E-Commerce System");



        stage.show();



    } catch (IOException e) {



        e.printStackTrace();



        System.out.println("Error: Could not load Login.fxml");



    }
}
@FXML
private void goToCart(ActionEvent event) {
    try {
        Parent cartRoot = FXMLLoader.load(getClass().getResource("CartPage.fxml"));
        Stage stage = (Stage) ((Node) event.getSource()).getScene().getWindow();
        Scene scene = new Scene(cartRoot);
        stage.setScene(scene);
        stage.setTitle("Cart - Furniture E-Commerce System");
        stage.show();
    } catch (IOException e) {
        e.printStackTrace();
        System.out.println("Error: Could not load CartPage.fxml");
    }
}

@FXML
private void goToSofa(ActionEvent event) {
    try {
        Parent sofaRoot = FXMLLoader.load(getClass().getResource("SofaPage.fxml"));
        Stage stage = (Stage) ((Node) event.getSource()).getScene().getWindow();
        Scene scene = new Scene(sofaRoot);
        stage.setScene(scene);
        stage.setTitle("Sofa - Furniture E-Commerce System");
        stage.show();
    } catch (IOException e) {
        e.printStackTrace();
        System.out.println("Error: Could not load SofaPage.fxml");
    }
}

@FXML
private void goToBed(ActionEvent event) {
    try {
        Parent bedRoot = FXMLLoader.load(getClass().getResource("BedPage.fxml"));
        Stage stage = (Stage) ((Node) event.getSource()).getScene().getWindow();
        Scene scene = new Scene(bedRoot);
        stage.setScene(scene);
        stage.setTitle("Bed - Furniture E-Commerce System");
        stage.show();
    } catch (IOException e) {
        e.printStackTrace();
        System.out.println("Error: Could not load BedPage.fxml");
    }
}

@FXML
private void goToTable(ActionEvent event) {
    try {
        Parent tableRoot = FXMLLoader.load(getClass().getResource("TablePage.fxml"));
        Stage stage = (Stage) ((Node) event.getSource()).getScene().getWindow();
        Scene scene = new Scene(tableRoot);
        stage.setScene(scene);
        stage.setTitle("Table - Furniture E-Commerce System");
        stage.show();
    } catch (IOException e) {
        e.printStackTrace();
        System.out.println("Error: Could not load TablePage.fxml");
    }
}

@Override
    public void initialize(URL url, ResourceBundle rb) {
        // TODO
    }    
    
}
