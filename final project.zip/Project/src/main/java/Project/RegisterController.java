package Project;

import javafx.fxml.FXML;
import javafx.scene.control.*;
import service.UserService;

public class RegisterController {

    @FXML private TextField usernameField;
    @FXML private TextField emailField;
    @FXML private PasswordField passwordField;
    @FXML private PasswordField confirmPasswordField;
    @FXML private ChoiceBox<String> roleChoice;
    @FXML private Label errorLabel;

    private final UserService userService = new UserService();

    @FXML
    private void initialize() {
        roleChoice.getItems().addAll("CUSTOMER", "SELLER");
    }

    @FXML
    private void handleRegister() {

        // 🔴 1. Empty field check
        if (usernameField.getText().isEmpty() ||
            emailField.getText().isEmpty() ||
            passwordField.getText().isEmpty() ||
            confirmPasswordField.getText().isEmpty() ||
            roleChoice.getValue() == null) {

            showAlert(
                Alert.AlertType.WARNING,
                "Missing Data",
                "Incomplete Registration",
                "Please fill in all fields before registering."
            );
            return;
        }

        // 🔴 2. Email must end with .com
        if (!emailField.getText().endsWith(".com")) {

            showAlert(
                Alert.AlertType.ERROR,
                "Invalid Email",
                "Email Format Error",
                "Email address must end with .com"
            );
            return;
        }

        // 🔴 3. Password match check
        if (!passwordField.getText().equals(confirmPasswordField.getText())) {

            showAlert(
                Alert.AlertType.ERROR,
                "Password Error",
                "Passwords Do Not Match",
                "Please make sure both passwords are identical."
            );
            return;
        }

        // 🟢 4. Register user
        userService.register(
                usernameField.getText(),
                emailField.getText(),
                passwordField.getText(),
                roleChoice.getValue()
        );

        // 🟢 5. Success message
        showAlert(
            Alert.AlertType.INFORMATION,
            "Registration Successful",
            null,
            "Account created successfully. Please log in."
        );

        // 🟢 6. Back to login
        App.setRoot("Login.fxml");
    }

    @FXML
    private void goToLogin() {
        App.setRoot("Login.fxml");
    }

    // 🔧 Utility alert method
    private void showAlert(Alert.AlertType type, String title, String header, String message) {
        Alert alert = new Alert(type);
        alert.setTitle(title);
        alert.setHeaderText(header);
        alert.setContentText(message);
        alert.showAndWait();
    }
}
