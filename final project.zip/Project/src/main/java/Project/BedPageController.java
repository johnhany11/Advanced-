package Project;

import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.fxml.Initializable;
import javafx.scene.Node;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Label; // Import Label
import javafx.scene.control.Button;
import javafx.stage.Stage;

import model.Bed;
import model.CartData;
import service.FurnitureService;

import java.io.IOException;
import java.net.URL;
import java.util.List;
import java.util.ResourceBundle;

public class BedPageController implements Initializable {

    private FurnitureService furnitureService;
    private List<Bed> availableBeds;

    // --- LABELS FOR UI ---
    // Bed 1
    @FXML private Label name1;
    @FXML private Label price1;
    @FXML private Label desc1;

    // Bed 2
    @FXML private Label name2;
    @FXML private Label price2;
    @FXML private Label desc2;

    // Bed 3
    @FXML private Label name3;
    @FXML private Label price3;
    @FXML private Label desc3;

    @FXML private Button addToCart1;
    @FXML private Button addToCart2;
    @FXML private Button addToCart3;
    @FXML private Button goToCart;

    @Override
    public void initialize(URL url, ResourceBundle rb) {
        furnitureService = new FurnitureService();
        
        // 1. Load Beds from Database
        availableBeds = furnitureService.getAllBeds();
        
        // 2. Display Data on Labels
        displayBedData();
        
        System.out.println("Bed Controller: Loaded " + availableBeds.size() + " beds.");
    }

    private void displayBedData() {
        // --- Bed 1 ---
        if (availableBeds.size() >= 1) {
            Bed b1 = availableBeds.get(0);
            name1.setText(b1.getName());
            price1.setText("$" + b1.getPrice());
            desc1.setText(b1.getDescription());
        }

        // --- Bed 2 ---
        if (availableBeds.size() >= 2) {
            Bed b2 = availableBeds.get(1);
            name2.setText(b2.getName());
            price2.setText("$" + b2.getPrice());
            desc2.setText(b2.getDescription());
        }

        // --- Bed 3 ---
        if (availableBeds.size() >= 3) {
            Bed b3 = availableBeds.get(2);
            name3.setText(b3.getName());
            price3.setText("$" + b3.getPrice());
            desc3.setText(b3.getDescription());
        }
    }

    // --- BUTTON ACTIONS ---

    @FXML
    private void addBed1() {
        if (availableBeds.size() >= 1) {
            CartData.addItem(availableBeds.get(0), 1);
            System.out.println("Added to Cart: " + availableBeds.get(0).getName());
        }
    }

    @FXML
    private void addBed2() {
        if (availableBeds.size() >= 2) {
            CartData.addItem(availableBeds.get(1), 1);
            System.out.println("Added to Cart: " + availableBeds.get(1).getName());
        }
    }

    @FXML
    private void addBed3() {
        if (availableBeds.size() >= 3) {
            CartData.addItem(availableBeds.get(2), 1);
            System.out.println("Added to Cart: " + availableBeds.get(2).getName());
        }
    }

    @FXML
    private void goToCart(ActionEvent event) {
        try {
            Parent root = FXMLLoader.load(getClass().getResource("CartPage.fxml"));
            Stage stage = (Stage) ((Node) event.getSource()).getScene().getWindow();
            stage.setScene(new Scene(root));
            stage.setTitle("Your Cart");
            stage.show();
        } catch (IOException e) {
            e.printStackTrace();
            System.out.println("Error loading CartPage.fxml");
        }
    }
}