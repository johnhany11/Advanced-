package Project;

import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.fxml.Initializable;
import javafx.scene.Node;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Label; // Import Label
import javafx.stage.Stage;

import model.Sofa;
import model.CartData;
import service.FurnitureService;

import java.io.IOException;
import java.net.URL;
import java.util.List;
import java.util.ResourceBundle;

public class SofaPageController implements Initializable {

    private FurnitureService furnitureService;
    private List<Sofa> availableSofas;

    // --- NEW: FXML Labels for the UI ---
    // Row 1
    @FXML private Label name1;
    @FXML private Label price1;
    @FXML private Label desc1;

    // Row 2
    @FXML private Label name2;
    @FXML private Label price2;
    @FXML private Label desc2;

    // Row 3
    @FXML private Label name3;
    @FXML private Label price3;
    @FXML private Label desc3;

    @Override
    public void initialize(URL url, ResourceBundle rb) {
        furnitureService = new FurnitureService();
        
        // 1. Get the data from the database
        availableSofas = furnitureService.getAllSofas();
        
        // 2. Display the data on the labels
        displaySofaData();
    }

    private void displaySofaData() {
        // --- SOFA 1 ---
        if (availableSofas.size() >= 1) {
            Sofa s1 = availableSofas.get(0);
            name1.setText(s1.getName());
            price1.setText("$" + s1.getPrice());
            desc1.setText(s1.getDescription()); // Uses the method we wrote in Sofa.java
        }

        // --- SOFA 2 ---
        if (availableSofas.size() >= 2) {
            Sofa s2 = availableSofas.get(1);
            name2.setText(s2.getName());
            price2.setText("$" + s2.getPrice());
            desc2.setText(s2.getDescription());
        }

        // --- SOFA 3 ---
        if (availableSofas.size() >= 3) {
            Sofa s3 = availableSofas.get(2);
            name3.setText(s3.getName());
            price3.setText("$" + s3.getPrice());
            desc3.setText(s3.getDescription());
        }
    }

    // --- Button Actions (Keep these the same) ---

    @FXML
    private void addSofa1() {
        if (availableSofas.size() >= 1) {
            CartData.addItem(availableSofas.get(0), 1);
            System.out.println("Added to Cart: " + availableSofas.get(0).getName());
        }
    }

    @FXML
    private void addSofa2() {
        if (availableSofas.size() >= 2) {
            CartData.addItem(availableSofas.get(1), 1);
            System.out.println("Added to Cart: " + availableSofas.get(1).getName());
        }
    }

    @FXML
    private void addSofa3() {
        if (availableSofas.size() >= 3) {
            CartData.addItem(availableSofas.get(2), 1);
            System.out.println("Added to Cart: " + availableSofas.get(2).getName());
        }
    }

    @FXML
    private void goToCart(ActionEvent event) {
        try {
            Parent root = FXMLLoader.load(getClass().getResource("CartPage.fxml"));
            Stage stage = (Stage) ((Node) event.getSource()).getScene().getWindow();
            stage.setScene(new Scene(root));
            stage.setTitle("Your Cart");
            stage.show();
        } catch (IOException e) {
            e.printStackTrace();
        }
    }
}